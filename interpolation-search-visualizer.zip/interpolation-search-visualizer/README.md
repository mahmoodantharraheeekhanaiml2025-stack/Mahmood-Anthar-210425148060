# Interpolation Search — Visual Trace

A DAA (Design & Analysis of Algorithms) lab project demonstrating **interpolation search**, with a live browser visualizer plus the original Python reference implementation and benchmark.

**[Live demo →](#)** *(update this link once GitHub Pages is enabled — see below)*

## What's inside

| File | Purpose |
|---|---|
| `index.html` | Self-contained interactive visualizer (no build step, no dependencies). Open it directly or serve via GitHub Pages. |
| `interpolation_search.py` | Reference implementation with a binary-search baseline and a `performance_analysis()` benchmark. |
| `LICENSE` | MIT license. |

## Why interpolation search

Binary search always checks the midpoint of the current range. Interpolation search instead *estimates* where the target should sit, assuming values are spread out roughly evenly — the same way you'd flip straight to "M" in a dictionary instead of opening in the middle every time.

```
pos = low + ((target - arr[low]) * (high - low)) / (arr[high] - arr[low])
```

| | Average case | Worst case | Space |
|---|---|---|---|
| Interpolation search | O(log log n) | O(n) | O(1) |
| Binary search | O(log n) | O(log n) | O(1) |

Interpolation search wins on large, uniformly distributed sorted data. It degrades to linear time on skewed distributions (e.g. many duplicate or clustered values), which is why the implementation here guards against `arr[high] == arr[low]` to avoid a division by zero.

## The visualizer

Open `index.html` in any browser (or host it with GitHub Pages — instructions below). It has three parts:

1. **Step tracer** — generates a random sorted array and plots it on a number line positioned by *value*, not index. Step through the search one probe at a time (or auto-play) and watch `low`, `high`, and the computed `pos` update alongside a running comparison count.
2. **Head-to-head** — runs interpolation search and binary search on the same array/target and compares comparison counts.
3. **Benchmark** — reproduces the Python `performance_analysis()` routine client-side across increasing array sizes (1,000 → 100,000 elements).

## Running the Python version

```bash
python interpolation_search.py
```

This prints a worked example, the benchmark table across five array sizes, and a few edge-case checks (exact-match target, an array of identical values, and a target that isn't present).

## Publishing this to GitHub

```bash
cd interpolation-search-visualizer
git init
git add .
git commit -m "Interpolation search: visualizer + reference implementation"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

To get a live link for the demo (and to fill in the link at the top of this README):

1. On GitHub, go to **Settings → Pages**.
2. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
3. Save — GitHub will publish `index.html` at `https://<your-username>.github.io/<repo-name>/`.

## Notes for the lab report

- Comparisons are counted per loop iteration in both algorithms, so the numbers shown in the visualizer and printed by the Python script are directly comparable.
- The benchmark generates a **new random uniformly-distributed sorted array** per size (via `random.sample`, unique values), which is the distribution interpolation search is best suited for. Try a clustered/skewed array to see the worst-case behavior converge toward binary search or worse.
- Edge cases already handled: single-element range, all-equal elements (`arr[high] == arr[low]`), and target outside the array's value range.
